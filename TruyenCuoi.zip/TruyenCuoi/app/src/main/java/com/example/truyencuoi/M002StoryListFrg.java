package com.example.truyencuoi;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class M002StoryListFrg extends Fragment implements StoryAdapter.IStory {

    private static final String KEY_TOPIC = "topicKey";

    private TextView tvTitle;
    private RecyclerView rv;
    private ImageView btnBack;
    private Switch swRotate;
    private ArrayList<StoryEntity> listStory;
    private String topicName;

    public static M002StoryListFrg newInstance(String topicName) {
        M002StoryListFrg frg = new M002StoryListFrg();
        Bundle b = new Bundle();
        b.putString(KEY_TOPIC, topicName);
        frg.setArguments(b);
        return frg;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.m002_frg_story_list, container, false);

        tvTitle = v.findViewById(R.id.tv_title_topic);
        rv = v.findViewById(R.id.rv_story_list);
        swRotate = v.findViewById(R.id.sw_rotate);
        btnBack = v.findViewById(R.id.btn_back_detail);

        topicName = getArguments().getString(KEY_TOPIC, "");
        tvTitle.setText("Chủ đề: " + topicName);

        initData();
        initList();

        // ================= BACK BUTTON =================
        btnBack.setOnClickListener(view -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).backToM001Screen();
            }
        });

        // ================= ROTATION SWITCH =================
        if (getActivity() instanceof MainActivity) {
            boolean allow = ((MainActivity) getActivity()).getAllowRotate();
            swRotate.setChecked(allow);

            swRotate.setOnCheckedChangeListener((btn, isChecked) ->
                    ((MainActivity) getActivity()).setAllowRotate(isChecked)
            );
        }

        return v;
    }

    private void initData() {
        listStory = new ArrayList<>();
        listStory.add(new StoryEntity("Vừa đúng vừa sai", "Nội dung truyện 1..."));
        listStory.add(new StoryEntity("Lợi hại", "Nội dung truyện 2..."));
        listStory.add(new StoryEntity("Cô gái thông minh", "Nội dung truyện 3..."));
    }

    private void initList() {
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        rv.setAdapter(new StoryAdapter(listStory, this));
    }

    @Override
    public void onStoryClick(StoryEntity story) {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).gotoM003Screen(listStory, story);
        }
    }
}
