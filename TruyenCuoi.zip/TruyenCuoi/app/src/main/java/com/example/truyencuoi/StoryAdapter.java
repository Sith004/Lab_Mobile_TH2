package com.example.truyencuoi;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class StoryAdapter extends RecyclerView.Adapter<StoryAdapter.StoryVH> {

    private final List<StoryEntity> list;
    private final IStory callback;

    public interface IStory {
        void onStoryClick(StoryEntity story);
    }

    public StoryAdapter(List<StoryEntity> list, IStory callback) {
        this.list = list;
        this.callback = callback;
    }

    @NonNull
    @Override
    public StoryVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new StoryVH(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_story, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull StoryVH holder, int position) {
        StoryEntity story = list.get(position);
        holder.tvName.setText(story.title);

        holder.itemView.setOnClickListener(v -> callback.onStoryClick(story));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class StoryVH extends RecyclerView.ViewHolder {
        TextView tvName;

        public StoryVH(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tv_story_name);
        }
    }
}
