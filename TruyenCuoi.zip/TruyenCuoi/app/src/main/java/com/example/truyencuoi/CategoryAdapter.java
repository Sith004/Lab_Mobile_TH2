package com.example.truyencuoi;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.CategoryVH> {

    private final List<String> list;
    private final ICategory callback;

    public interface ICategory {
        void onCategoryClick(String topicName);
    }

    public CategoryAdapter(List<String> list, ICategory callback) {
        this.list = list;
        this.callback = callback;
    }

    @NonNull
    @Override
    public CategoryVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_category, parent, false);
        return new CategoryVH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryVH holder, int position) {
        String topic = list.get(position);
        holder.tvName.setText(topic);

        holder.itemView.setOnClickListener(view -> {
            callback.onCategoryClick(topic);
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class CategoryVH extends RecyclerView.ViewHolder {

        TextView tvName;
        ImageView img;

        public CategoryVH(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tv_category);
            img = itemView.findViewById(R.id.img_category);
        }
    }
}
