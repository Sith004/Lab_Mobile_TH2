package com.example.truyencuoi;

import android.os.Bundle;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class M003StoryDetailFrg extends Fragment {

    private static final String KEY_LIST = "keyListStory";
    private static final String KEY_STORY = "keyStory";

    private ArrayList<StoryEntity> listStory;
    private StoryEntity currentStory;
    private int index;

    private TextView tvTitle, tvContent;
    private ImageView btnBack;
    private Switch swRotate;

    private GestureDetector gestureDetector;

    public static M003StoryDetailFrg newInstance(ArrayList<StoryEntity> list, StoryEntity selected) {
        M003StoryDetailFrg frg = new M003StoryDetailFrg();
        Bundle b = new Bundle();
        b.putSerializable(KEY_LIST, list);
        b.putSerializable(KEY_STORY, selected);
        frg.setArguments(b);
        return frg;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.m003_frg_story_detail, container, false);

        tvTitle = v.findViewById(R.id.tv_detail_title);
        tvContent = v.findViewById(R.id.tv_detail_content);
        btnBack = v.findViewById(R.id.btn_back_detail);
        swRotate = v.findViewById(R.id.sw_rotate);

        listStory = (ArrayList<StoryEntity>) getArguments().getSerializable(KEY_LIST);
        currentStory = (StoryEntity) getArguments().getSerializable(KEY_STORY);

        index = listStory.indexOf(currentStory);
        showStory();

        // ================= BACK =================
        btnBack.setOnClickListener(view -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).backToM002Screen();
            }
        });

        // ================= ROTATION =================
        if (getActivity() instanceof MainActivity) {
            boolean allow = ((MainActivity) getActivity()).getAllowRotate();
            swRotate.setChecked(allow);

            swRotate.setOnCheckedChangeListener((btn, isChecked) ->
                    ((MainActivity) getActivity()).setAllowRotate(isChecked)
            );
        }

        setupSwipe(v);
        return v;
    }

    private void showStory() {
        tvTitle.setText(currentStory.title);
        tvContent.setText(currentStory.content);
    }

    private void setupSwipe(View root) {

        gestureDetector = new GestureDetector(getContext(),
                new GestureDetector.SimpleOnGestureListener() {

                    private static final int DIST = 150;
                    private static final int VEL = 150;

                    @Override
                    public boolean onFling(MotionEvent e1, MotionEvent e2, float vX, float vY) {
                        float dx = e2.getX() - e1.getX();

                        if (Math.abs(dx) > DIST && Math.abs(vX) > VEL) {
                            if (dx < 0) nextStory();
                            else previousStory();

                            return true;
                        }
                        return false;
                    }
                });

        root.setOnTouchListener((v, ev) -> gestureDetector.onTouchEvent(ev));
    }

    private void nextStory() {
        if (index < listStory.size() - 1) {
            index++;
            currentStory = listStory.get(index);
            showStory();
        }
    }

    private void previousStory() {
        if (index > 0) {
            index--;
            currentStory = listStory.get(index);
            showStory();
        }
    }
}
