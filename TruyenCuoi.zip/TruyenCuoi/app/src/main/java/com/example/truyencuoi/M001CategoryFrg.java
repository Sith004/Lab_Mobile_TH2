package com.example.truyencuoi;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Switch;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.List;

public class M001CategoryFrg extends Fragment implements CategoryAdapter.ICategory {

    private RecyclerView rv;
    private Switch swRotate;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.m001_frg_category, container, false);

        rv = v.findViewById(R.id.rv_categories);
        swRotate = v.findViewById(R.id.sw_rotate);

        if (getActivity() instanceof MainActivity) {
            boolean allow = ((MainActivity) getActivity()).getAllowRotate();
            swRotate.setChecked(allow);

            swRotate.setOnCheckedChangeListener((btn, isChecked) ->
                    ((MainActivity) getActivity()).setAllowRotate(isChecked)
            );
        }

        initList();
        return v;
    }

    private void initList() {
        List<String> data = Arrays.asList(
                "Con gái", "Công nghệ", "Việc học",
                "Bạn bè", "Gia đình", "Tin nhắn",
                "Vợ chồng", "Hài hước 18+"
        );

        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        rv.setAdapter(new CategoryAdapter(data, this));
    }

    @Override
    public void onCategoryClick(String topicName) {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).gotoM002Screen(topicName);
        }
    }
}
