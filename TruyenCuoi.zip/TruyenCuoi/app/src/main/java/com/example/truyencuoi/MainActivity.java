package com.example.truyencuoi;

import android.content.pm.ActivityInfo;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private boolean allowRotate = false;
    private String topicName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        showFrg(new M000SplashFrg(), false);
    }

    private void showFrg(Fragment frg, boolean addToBackStack) {
        FragmentTransaction ft = getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.ln_main, frg, frg.getClass().getSimpleName());
        if (addToBackStack) ft.addToBackStack(null);
        ft.commit();
    }
    public void gotoM001Screen() {
        showFrg(new M001CategoryFrg(), false);
    }

    public void gotoM002Screen(String topicName) {
        this.topicName = topicName;
        showFrg(M002StoryListFrg.newInstance(topicName), true);
    }

    public void gotoM003Screen(ArrayList<StoryEntity> listStory, StoryEntity story) {
        showFrg(M003StoryDetailFrg.newInstance(listStory, story), true);
    }

    public void backToM002Screen() {
        getSupportFragmentManager().popBackStack();
    }

    public void backToM001Screen() {
        getSupportFragmentManager().popBackStack();
    }

    public void setAllowRotate(boolean allow) {
        allowRotate = allow;

        if (allowRotate) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }

    public boolean getAllowRotate() {
        return allowRotate;
    }
}
