package com.example.truyencuoi;

import java.io.Serializable;

public class StoryEntity implements Serializable {
    public String title;
    public String content;

    public StoryEntity() {}

    public StoryEntity(String t, String c) {
        title = t;
        content = c;
    }
}
