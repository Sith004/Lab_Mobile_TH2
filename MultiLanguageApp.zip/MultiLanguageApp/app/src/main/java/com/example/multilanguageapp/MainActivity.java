package com.example.multilanguageapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tvVi, tvEn, tvFr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvVi = findViewById(R.id.tvVi);
        tvEn = findViewById(R.id.tvEn);
        tvFr = findViewById(R.id.tvFr);

        tvVi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LocaleHelper.setLocale(MainActivity.this, "vi");
            }
        });

        tvEn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LocaleHelper.setLocale(MainActivity.this, "en");
            }
        });

        tvFr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LocaleHelper.setLocale(MainActivity.this, "fr");
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // nạp menu từ XML
        getMenuInflater().inflate(R.menu.menu_language, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_vi) {
            LocaleHelper.setLocale(this, "vi");
            return true;
        } else if (id == R.id.action_en) {
            LocaleHelper.setLocale(this, "en");
            return true;
        } else if (id == R.id.action_fr) {
            LocaleHelper.setLocale(this, "fr");
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
